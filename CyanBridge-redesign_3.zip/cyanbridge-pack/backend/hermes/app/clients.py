"""HTTP-клиенты к внешним сервисам пайплайна.

Все эндпоинты — реальные:
  - whisper.cpp server:  POST /inference  (multipart: file)
  - edge-tts (travisvn):  POST /v1/audio/speech  (OpenAI-совместимый)
  - OpenRouter:           POST /v1/chat/completions  (OpenAI-совместимый)
"""
from __future__ import annotations

import httpx

from .config import Settings


class WhisperClient:
    """STT через whisper.cpp HTTP server (эндпоинт /inference)."""

    def __init__(self, base_url: str, timeout: float):
        self._base = base_url.rstrip("/")
        self._timeout = timeout

    async def transcribe(
        self,
        audio: bytes,
        filename: str = "audio.wav",
        language: str | None = None,
    ) -> str:
        files = {"file": (filename, audio, "application/octet-stream")}
        data = {"response_format": "json", "temperature": "0.0"}
        if language and language != "auto":
            data["language"] = language
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(f"{self._base}/inference", files=files, data=data)
            resp.raise_for_status()
            payload = resp.json()
        # whisper.cpp возвращает {"text": "..."} (иногда с ключом "transcription")
        return (payload.get("text") or payload.get("transcription") or "").strip()


class EdgeTtsClient:
    """TTS через edge-tts (OpenAI-совместимый /v1/audio/speech). Отдаёт opus."""

    def __init__(self, base_url: str, api_key: str, timeout: float):
        self._base = base_url.rstrip("/")
        self._api_key = api_key
        self._timeout = timeout

    async def synthesize(
        self,
        text: str,
        voice: str,
        response_format: str = "opus",
        speed: float = 1.0,
    ) -> bytes:
        headers = {"Authorization": f"Bearer {self._api_key}"}
        body = {
            "model": "tts-1",
            "input": text,
            "voice": voice,
            "response_format": response_format,
            "speed": speed,
        }
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(
                f"{self._base}/v1/audio/speech", json=body, headers=headers,
            )
            resp.raise_for_status()
            return resp.content


class OpenRouterClient:
    """LLM через OpenRouter (OpenAI-совместимый chat/completions)."""

    def __init__(self, base_url: str, api_key: str, model: str, timeout: float):
        self._base = base_url.rstrip("/")
        self._api_key = api_key
        self._model = model
        self._timeout = timeout

    async def chat(self, messages: list[dict], model: str | None = None) -> str:
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "HTTP-Referer": "https://github.com/cyanbridge",
            "X-Title": "CyanBridge",
        }
        body = {"model": model or self._model, "messages": messages}
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(
                f"{self._base}/chat/completions", json=body, headers=headers,
            )
            resp.raise_for_status()
            data = resp.json()
        return data["choices"][0]["message"]["content"].strip()


class FlowiseClient:
    """Опциональный вызов AI-workflow во Flowise (prediction API)."""

    def __init__(self, base_url: str, timeout: float):
        self._base = base_url.rstrip("/")
        self._timeout = timeout

    async def predict(self, chatflow_id: str, question: str, session_id: str | None = None) -> str:
        body: dict = {"question": question}
        if session_id:
            body["overrideConfig"] = {"sessionId": session_id}
        async with httpx.AsyncClient(timeout=self._timeout) as client:
            resp = await client.post(
                f"{self._base}/api/v1/prediction/{chatflow_id}", json=body,
            )
            resp.raise_for_status()
            data = resp.json()
        # Flowise возвращает {"text": "..."} или строку
        if isinstance(data, dict):
            return (data.get("text") or data.get("answer") or "").strip()
        return str(data).strip()


def build_clients(s: Settings):
    return (
        WhisperClient(s.whisper_url, s.request_timeout_s),
        EdgeTtsClient(s.edge_tts_url, s.edge_tts_api_key, s.request_timeout_s),
        OpenRouterClient(s.openrouter_url, s.openrouter_api_key, s.openrouter_model, s.request_timeout_s),
        FlowiseClient(s.flowise_url, s.request_timeout_s),
    )
