from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """Конфигурация Hermes. Значения берутся из окружения / .env."""

    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    # Внутренние сервисы (имена из docker-compose)
    whisper_url: str = "http://whisper:9000"
    edge_tts_url: str = "http://edge-tts:5050"
    flowise_url: str = "http://flowise:3000"

    # Хранилища
    database_url: str = "postgresql+asyncpg://cyan:cyan@postgres:5432/cyanbridge"
    redis_url: str = "redis://redis:6379/0"

    # OpenRouter (LLM)
    openrouter_api_key: str = ""
    openrouter_model: str = "anthropic/claude-3.5-sonnet"
    openrouter_url: str = "https://openrouter.ai/api/v1"

    # TTS / язык
    edge_tts_api_key: str = "cyanbridge-local"
    hermes_default_voice: str = "en-US-AriaNeural"
    hermes_default_language: str = "auto"

    # Поведение
    request_timeout_s: float = 60.0


@lru_cache
def get_settings() -> Settings:
    return Settings()
