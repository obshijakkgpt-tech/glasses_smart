"""Hermes — оркестратор голосового ассистента CyanBridge.

Пайплайн /v1/voice:
  аудио -> whisper.cpp (STT) -> LLM (Flowise или OpenRouter) -> edge-tts (TTS)
  -> ответ (audio + распознанный/сгенерированный текст в заголовках).
"""
from __future__ import annotations

import base64
from contextlib import asynccontextmanager

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import JSONResponse, Response
from pydantic import BaseModel

from .clients import build_clients
from .config import get_settings

settings = get_settings()
whisper, edge_tts, openrouter, flowise = build_clients(settings)

SYSTEM_PROMPT = (
    "Ты — голосовой ассистент умных очков. Отвечай кратко и по делу, "
    "одним-двумя предложениями, пригодными для озвучивания."
)


@asynccontextmanager
async def lifespan(app: FastAPI):
    # место для инициализации пулов БД/Redis (добавим на шаге B6)
    yield


app = FastAPI(title="Hermes", version="0.1.0", lifespan=lifespan)


@app.get("/health")
async def health():
    return {"status": "ok", "service": "hermes"}


class ChatRequest(BaseModel):
    text: str
    session_id: str | None = None
    chatflow_id: str | None = None


class ChatResponse(BaseModel):
    reply: str


async def _generate_reply(text: str, session_id: str | None, chatflow_id: str | None) -> str:
    """Получить текстовый ответ: через Flowise (если задан chatflow) или OpenRouter."""
    if chatflow_id:
        return await flowise.predict(chatflow_id, text, session_id)
    if not settings.openrouter_api_key:
        raise HTTPException(status_code=503, detail="LLM не настроен: задайте OPENROUTER_API_KEY или chatflow_id")
    messages = [
        {"role": "system", "content": SYSTEM_PROMPT},
        {"role": "user", "content": text},
    ]
    return await openrouter.chat(messages)


@app.post("/v1/chat", response_model=ChatResponse)
async def chat(req: ChatRequest):
    reply = await _generate_reply(req.text, req.session_id, req.chatflow_id)
    return ChatResponse(reply=reply)


@app.post("/v1/voice")
async def voice(
    file: UploadFile = File(...),
    session_id: str | None = Form(default=None),
    chatflow_id: str | None = Form(default=None),
    voice: str | None = Form(default=None),
    language: str | None = Form(default=None),
    audio_format: str = Form(default="opus"),
):
    """Полный голосовой цикл: аудио -> текст -> ответ -> аудио.

    Возвращает синтезированное аудио (bytes). Распознанный запрос и текст
    ответа кладутся в заголовки X-Transcript / X-Reply (base64, чтобы
    безопасно передавать любой юникод).
    """
    audio_bytes = await file.read()
    if not audio_bytes:
        raise HTTPException(status_code=400, detail="Пустой аудиофайл")

    # 1) STT
    transcript = await whisper.transcribe(
        audio_bytes,
        filename=file.filename or "audio.wav",
        language=language or settings.hermes_default_language,
    )
    if not transcript:
        raise HTTPException(status_code=422, detail="Не удалось распознать речь")

    # 2) LLM
    reply = await _generate_reply(transcript, session_id, chatflow_id)

    # 3) TTS
    audio_out = await edge_tts.synthesize(
        reply,
        voice=voice or settings.hermes_default_voice,
        response_format=audio_format,
    )

    media_type = {
        "opus": "audio/ogg",
        "mp3": "audio/mpeg",
        "wav": "audio/wav",
        "aac": "audio/aac",
        "flac": "audio/flac",
    }.get(audio_format, "application/octet-stream")

    headers = {
        "X-Transcript": base64.b64encode(transcript.encode("utf-8")).decode("ascii"),
        "X-Reply": base64.b64encode(reply.encode("utf-8")).decode("ascii"),
    }
    return Response(content=audio_out, media_type=media_type, headers=headers)


@app.exception_handler(Exception)
async def unhandled(_, exc: Exception):
    return JSONResponse(status_code=500, content={"detail": f"Внутренняя ошибка: {exc}"})
