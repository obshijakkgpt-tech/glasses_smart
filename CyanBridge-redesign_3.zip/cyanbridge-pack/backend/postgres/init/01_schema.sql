-- Инициализация БД CyanBridge: pgvector + схема ассистента.
-- Выполняется автоматически при первом старте контейнера postgres.

CREATE EXTENSION IF NOT EXISTS vector;

-- Сессии диалога (одна на разговор / устройство)
CREATE TABLE IF NOT EXISTS sessions (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    device_id   TEXT,                       -- MAC очков / id приложения
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Сообщения в сессии (история диалога)
CREATE TABLE IF NOT EXISTS messages (
    id          BIGSERIAL PRIMARY KEY,
    session_id  UUID NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    role        TEXT NOT NULL CHECK (role IN ('user','assistant','system')),
    content     TEXT NOT NULL,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id, created_at);

-- Семантическая память (RAG): эмбеддинги фрагментов
-- Размерность 1536 — под распространённые эмбеддинг-модели; при смене
-- модели поменять размерность и пересоздать индекс.
CREATE TABLE IF NOT EXISTS memories (
    id          BIGSERIAL PRIMARY KEY,
    session_id  UUID REFERENCES sessions(id) ON DELETE CASCADE,
    content     TEXT NOT NULL,
    embedding   vector(1536),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- HNSW-индекс для быстрого ANN-поиска по косинусу
CREATE INDEX IF NOT EXISTS idx_memories_embedding
    ON memories USING hnsw (embedding vector_cosine_ops);
