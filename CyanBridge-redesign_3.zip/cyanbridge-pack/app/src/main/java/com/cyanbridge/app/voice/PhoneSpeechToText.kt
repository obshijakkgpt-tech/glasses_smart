package com.cyanbridge.app.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow

/** Событие распознавания речи. */
sealed interface SttEvent {
    data object ReadyForSpeech : SttEvent
    data object BeginningOfSpeech : SttEvent
    data class Partial(val text: String) : SttEvent
    data class Final(val text: String) : SttEvent
    data class Error(val code: Int, val message: String) : SttEvent
}

/**
 * Речь -> текст через системный Android SpeechRecognizer.
 * Это «телефон как микрофон» для режима без очков. Работает офлайн при
 * наличии офлайн-языкового пакета, иначе через сетевой распознаватель.
 *
 * Требует разрешения RECORD_AUDIO (запрашивается в UI).
 */
class PhoneSpeechToText(private val context: Context) {

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    /**
     * Запустить распознавание. Возвращает поток событий; отмена потока
     * (или закрытие) останавливает распознаватель.
     */
    fun listen(languageTag: String? = null): Flow<SttEvent> = callbackFlow {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            trySend(SttEvent.Error(-1, "Распознавание речи недоступно на устройстве"))
            close()
            return@callbackFlow
        }

        val recognizer = SpeechRecognizer.createSpeechRecognizer(context)
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM,
            )
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            if (!languageTag.isNullOrBlank() && languageTag != "auto") {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, languageTag)
            }
        }

        val listener = object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { trySend(SttEvent.ReadyForSpeech) }
            override fun onBeginningOfSpeech() { trySend(SttEvent.BeginningOfSpeech) }
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}

            override fun onError(error: Int) {
                trySend(SttEvent.Error(error, sttErrorMessage(error)))
                close()
            }

            override fun onResults(results: Bundle?) {
                val text = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                trySend(SttEvent.Final(text))
                close()
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (text.isNotBlank()) trySend(SttEvent.Partial(text))
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }

        recognizer.setRecognitionListener(listener)
        recognizer.startListening(intent)

        awaitClose {
            recognizer.stopListening()
            recognizer.destroy()
        }
    }
}

private fun sttErrorMessage(code: Int): String = when (code) {
    SpeechRecognizer.ERROR_AUDIO -> "Ошибка аудиозаписи"
    SpeechRecognizer.ERROR_CLIENT -> "Ошибка клиента"
    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Нет разрешения на микрофон"
    SpeechRecognizer.ERROR_NETWORK -> "Сетевая ошибка"
    SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Таймаут сети"
    SpeechRecognizer.ERROR_NO_MATCH -> "Речь не распознана"
    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Распознаватель занят"
    SpeechRecognizer.ERROR_SERVER -> "Ошибка сервера распознавания"
    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Не услышал речь"
    else -> "Неизвестная ошибка распознавания ($code)"
}
