package com.cyanbridge.app.ui.screens.settings

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.cyanbridge.app.data.settings.DeviceModeSetting

@Composable
fun SettingsScreen(vm: SettingsViewModel = viewModel()) {
    val s by vm.settings.collectAsStateWithLifecycle()
    val test by vm.testResult.collectAsStateWithLifecycle()

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            Text(
                "Настройки",
                style = MaterialTheme.typography.headlineMedium,
                color = MaterialTheme.colorScheme.onBackground,
            )

            SectionTitle("Сервер Hermes")
            OutlinedTextField(
                value = s.hermesUrl,
                onValueChange = vm::setHermesUrl,
                label = { Text("Адрес сервера (например http://192.168.1.50:8642)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = s.hermesApiKey,
                onValueChange = vm::setHermesKey,
                label = { Text("API-ключ (Bearer)") },
                singleLine = true,
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = s.openRouterModel,
                onValueChange = vm::setModel,
                label = { Text("Модель (OpenRouter / серверная)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
            ) {
                Button(onClick = vm::testConnection) { Text("Проверить соединение") }
                Text(
                    text = testLabel(test),
                    style = MaterialTheme.typography.bodyMedium,
                    color = when (test) {
                        TestResult.OK -> MaterialTheme.colorScheme.primary
                        TestResult.FAIL -> MaterialTheme.colorScheme.error
                        else -> MaterialTheme.colorScheme.onSurfaceVariant
                    },
                )
            }

            SectionTitle("Голос")
            OutlinedTextField(
                value = s.sttLanguage,
                onValueChange = vm::setSttLang,
                label = { Text("Язык распознавания (например ru-RU или auto)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = s.ttsVoiceLanguage,
                onValueChange = vm::setTtsLang,
                label = { Text("Язык озвучки (например ru-RU или auto)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )

            SectionTitle("Режим устройства")
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FilterChip(
                    selected = s.deviceMode == DeviceModeSetting.FAKE,
                    onClick = { vm.setMode(DeviceModeSetting.FAKE) },
                    label = { Text("Без очков (телефон)") },
                )
                FilterChip(
                    selected = s.deviceMode == DeviceModeSetting.NATIVE,
                    onClick = { vm.setMode(DeviceModeSetting.NATIVE) },
                    label = { Text("Очки HeyCyan") },
                )
            }
            Text(
                "В режиме «без очков» микрофон и динамик телефона используются " +
                    "напрямую — удобно для разработки и работы без устройства.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Spacer(Modifier.height(20.dp))
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.titleMedium,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.Medium,
    )
}

private fun testLabel(t: TestResult): String = when (t) {
    TestResult.NONE -> ""
    TestResult.TESTING -> "Проверяю…"
    TestResult.OK -> "Соединение успешно"
    TestResult.FAIL -> "Не удалось подключиться"
}
