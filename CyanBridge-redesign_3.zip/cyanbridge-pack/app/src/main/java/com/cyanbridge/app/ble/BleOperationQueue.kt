package com.cyanbridge.app.ble

import android.os.Handler
import android.os.Looper
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Очередь BLE-операций. На Android GATT-операции (read/write/discover/
 * подписка) ДОЛЖНЫ выполняться строго по одной: следующую можно начинать
 * только после колбэка о завершении предыдущей. Иначе они молча теряются.
 *
 * Это не специфика HeyCyan, а фундаментальное требование Android BLE —
 * поэтому здесь нет догадок о протоколе, только корректная механика.
 */
internal class BleOperationQueue {

    private val queue = ConcurrentLinkedQueue<() -> Unit>()
    private val busy = AtomicBoolean(false)
    private val main = Handler(Looper.getMainLooper())

    /** Поставить операцию в очередь и попытаться запустить. */
    fun enqueue(op: () -> Unit) {
        queue.add(op)
        next()
    }

    /** Вызывается из GATT-колбэков, когда текущая операция завершилась. */
    fun completed() {
        busy.set(false)
        next()
    }

    /** Сбросить очередь (при дисконнекте). */
    fun clear() {
        queue.clear()
        busy.set(false)
    }

    private fun next() {
        if (busy.get()) return
        val op = queue.poll() ?: return
        busy.set(true)
        // Гарантируем выполнение в main-потоке: часть GATT-операций
        // требует этого на ряде прошивок.
        main.post {
            try {
                op()
            } catch (t: Throwable) {
                busy.set(false)
                next()
            }
        }
    }
}
