package com.cyanbridge.app.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.suspendCancellableCoroutine
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

/**
 * Текст -> речь через системный Android TextToSpeech.
 * «Телефон как динамик» для режима без очков.
 */
class PhoneTextToSpeech(context: Context) {

    @Volatile private var ready = false
    private var tts: TextToSpeech? = null

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
        }
    }

    fun setLanguage(languageTag: String?) {
        val locale = if (languageTag.isNullOrBlank() || languageTag == "auto") {
            Locale.getDefault()
        } else {
            Locale.forLanguageTag(languageTag)
        }
        tts?.language = locale
    }

    /** Произнести текст и дождаться завершения. */
    suspend fun speak(text: String): Result<Unit> {
        val engine = tts ?: return Result.failure(IllegalStateException("TTS не инициализирован"))
        if (!ready) return Result.failure(IllegalStateException("TTS ещё не готов"))
        if (text.isBlank()) return Result.success(Unit)

        return suspendCancellableCoroutine { cont ->
            val id = UUID.randomUUID().toString()
            engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) {
                    if (utteranceId == id && cont.isActive) cont.resume(Result.success(Unit))
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    if (utteranceId == id && cont.isActive) {
                        cont.resume(Result.failure(IllegalStateException("Ошибка TTS")))
                    }
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    if (utteranceId == id && cont.isActive) {
                        cont.resume(Result.failure(IllegalStateException("Ошибка TTS ($errorCode)")))
                    }
                }
            })
            val res = engine.speak(text, TextToSpeech.QUEUE_FLUSH, null, id)
            if (res == TextToSpeech.ERROR && cont.isActive) {
                cont.resume(Result.failure(IllegalStateException("Не удалось запустить TTS")))
            }
            cont.invokeOnCancellation { engine.stop() }
        }
    }

    fun stop() { tts?.stop() }

    fun release() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        ready = false
    }
}
