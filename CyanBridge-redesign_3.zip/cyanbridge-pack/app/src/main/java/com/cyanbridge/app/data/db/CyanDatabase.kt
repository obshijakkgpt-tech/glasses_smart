package com.cyanbridge.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters

@Database(
    entities = [HistoryEntity::class, AudioJobEntity::class],
    version = 1,
    exportSchema = false, // MVP: схему не экспортируем (избегаем настройки schemaLocation)
)
@TypeConverters(Converters::class)
abstract class CyanDatabase : RoomDatabase() {
    abstract fun historyDao(): HistoryDao
    abstract fun audioJobDao(): AudioJobDao

    companion object {
        @Volatile private var instance: CyanDatabase? = null

        fun get(context: Context): CyanDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    CyanDatabase::class.java,
                    "cyanbridge.db",
                ).fallbackToDestructiveMigration().build().also { instance = it }
            }
    }
}
