package com.cyanbridge.app.voice

/**
 * Состояния голосового цикла. Главный риск MVP — UX задержки (3-7с),
 * поэтому каждое состояние явно показывается пользователю.
 */
enum class PipelineState(val label: String) {
    IDLE("Готов"),
    LISTENING("Слушаю…"),
    TRANSCRIBING("Распознаю…"),
    THINKING("Думаю…"),
    SPEAKING("Озвучиваю…"),
    ERROR("Ошибка"),
}
