package com.cyanbridge.app.ui.screens.home

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cyanbridge.app.data.db.CyanDatabase
import com.cyanbridge.app.data.settings.SettingsRepository
import com.cyanbridge.app.hermes.HermesClient
import com.cyanbridge.app.voice.PhoneSpeechToText
import com.cyanbridge.app.voice.PhoneTextToSpeech
import com.cyanbridge.app.voice.PipelineState
import com.cyanbridge.app.voice.SttEvent
import com.cyanbridge.app.voice.VoicePipeline
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

/** Состояние сервера Hermes для индикатора на Home. */
enum class ServerStatus { UNKNOWN, CHECKING, ONLINE, OFFLINE }

data class HomeUiState(
    val pipeline: PipelineState = PipelineState.IDLE,
    val partialTranscript: String = "",
    val lastTranscript: String = "",
    val lastReply: String = "",
    val serverStatus: ServerStatus = ServerStatus.UNKNOWN,
    val errorMessage: String? = null,
)

class VoiceViewModel(app: Application) : AndroidViewModel(app) {

    private val settingsRepo = SettingsRepository(app)
    private val db = CyanDatabase.get(app)
    private val stt = PhoneSpeechToText(app)
    private val tts = PhoneTextToSpeech(app)

    private val _ui = MutableStateFlow(HomeUiState())
    val ui: StateFlow<HomeUiState> = _ui.asStateFlow()

    private var pipeline: VoicePipeline? = null
    private var hermes: HermesClient? = null

    init {
        // Перестраиваем клиента Hermes при изменении настроек
        viewModelScope.launch {
            settingsRepo.settings.collect { s ->
                hermes = HermesClient(
                    baseUrl = s.hermesUrl,
                    apiKey = s.hermesApiKey,
                    model = s.openRouterModel,
                )
                tts.setLanguage(s.ttsVoiceLanguage)
                pipeline = VoicePipeline(
                    hermes = hermes!!,
                    tts = tts,
                    historyDao = db.historyDao(),
                    audioJobDao = db.audioJobDao(),
                )
                // Подписка на состояние пайплайна
                pipeline?.let { p ->
                    launch { p.state.collect { st -> _ui.value = _ui.value.copy(pipeline = st) } }
                    launch { p.lastTranscript.collect { t -> _ui.value = _ui.value.copy(lastTranscript = t) } }
                    launch { p.lastReply.collect { r -> _ui.value = _ui.value.copy(lastReply = r) } }
                }
            }
        }
    }

    fun checkServer() {
        viewModelScope.launch {
            _ui.value = _ui.value.copy(serverStatus = ServerStatus.CHECKING)
            val s = settingsRepo.settings.first()
            if (s.hermesUrl.isBlank()) {
                _ui.value = _ui.value.copy(serverStatus = ServerStatus.OFFLINE, errorMessage = "Не задан адрес Hermes (Настройки)")
                return@launch
            }
            val online = hermes?.health()?.getOrDefault(false) ?: false
            _ui.value = _ui.value.copy(
                serverStatus = if (online) ServerStatus.ONLINE else ServerStatus.OFFLINE,
            )
        }
    }

    /** Push-to-talk: запустить распознавание и прогнать через пайплайн. */
    fun startTalking() {
        val p = pipeline ?: return
        viewModelScope.launch {
            val s = settingsRepo.settings.first()
            _ui.value = _ui.value.copy(errorMessage = null, partialTranscript = "")
            p.onListening()
            stt.listen(languageTag = s.sttLanguage).collect { ev ->
                when (ev) {
                    is SttEvent.ReadyForSpeech, SttEvent.BeginningOfSpeech -> {}
                    is SttEvent.Partial ->
                        _ui.value = _ui.value.copy(partialTranscript = ev.text)
                    is SttEvent.Final -> {
                        p.onTranscribing()
                        val text = ev.text.ifBlank { _ui.value.partialTranscript }
                        if (text.isBlank()) {
                            p.onSttError("Речь не распознана")
                            _ui.value = _ui.value.copy(errorMessage = "Речь не распознана")
                        } else {
                            val res = p.handleTranscript(text)
                            res.onFailure {
                                _ui.value = _ui.value.copy(errorMessage = it.message)
                            }
                        }
                    }
                    is SttEvent.Error -> {
                        p.onSttError(ev.message)
                        _ui.value = _ui.value.copy(errorMessage = ev.message)
                    }
                }
            }
        }
    }

    fun dismissError() { _ui.value = _ui.value.copy(errorMessage = null) }

    override fun onCleared() {
        super.onCleared()
        tts.release()
    }
}
