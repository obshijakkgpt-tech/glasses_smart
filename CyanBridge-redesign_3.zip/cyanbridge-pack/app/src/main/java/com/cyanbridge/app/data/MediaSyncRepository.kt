package com.cyanbridge.app.data

import com.cyanbridge.app.net.GlassesWifiClient
import com.cyanbridge.app.net.MediaItem
import com.cyanbridge.app.net.MediaType
import com.cyanbridge.app.net.OggOpusWriter
import com.cyanbridge.app.net.SyncEvent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import kotlin.coroutines.coroutineContext

/**
 * Оркестратор выгрузки медиа с очков:
 *   1) найти базовый URL точки доступа
 *   2) скачать и распарсить media.config
 *   3) для каждого файла: скачать -> (если raw-opus) завернуть в Ogg ->
 *      сохранить в DCIM/CyanBridge через MediaStore
 *   4) эмитить события прогресса
 *
 * Возвращает Flow<SyncEvent>, который UI-слой просто собирает.
 */
class MediaSyncRepository(
    private val wifi: GlassesWifiClient,
    private val saver: MediaStoreSaver,
) {

    fun sync(): Flow<SyncEvent> = flow {
        val baseUrl = wifi.resolveBaseUrl()
        if (baseUrl == null) {
            emit(SyncEvent.Failed(null, "Не найдена точка доступа очков. Включите режим передачи и подключитесь к WiFi очков."))
            return@flow
        }
        emit(SyncEvent.BaseUrlResolved(baseUrl))

        val items = runCatching { wifi.fetchManifest(baseUrl) }
            .getOrElse {
                emit(SyncEvent.Failed(null, "Не удалось прочитать манифест: ${it.message}"))
                return@flow
            }
        emit(SyncEvent.ManifestLoaded(items))

        items.forEachIndexed { index, item ->
            coroutineContext.ensureActive()
            try {
                val (stream, total) = wifi.openFile(baseUrl, item)
                stream.use { input ->
                    val (outName, toSave) = prepareForSave(item, input)
                    emit(
                        SyncEvent.Progress(
                            com.cyanbridge.app.net.DownloadProgress(
                                item = item,
                                bytesRead = total ?: 0L,
                                totalBytes = total,
                                index = index + 1,
                                count = items.size,
                            ),
                        ),
                    )
                    val uri = saver.save(item, outName, toSave)
                    emit(SyncEvent.FileSaved(item, uri))
                }
            } catch (t: Throwable) {
                coroutineContext.ensureActive()
                emit(SyncEvent.Failed(item, t.message ?: "Ошибка при скачивании ${item.name}"))
            }
        }

        emit(SyncEvent.Completed)
    }.flowOn(Dispatchers.IO)

    /**
     * Подготовить файл к сохранению. Для аудио с очков:
     *  - если поток уже начинается с 'OggS' — это валидный Ogg, сохраняем как есть;
     *  - иначе считаем поток сырыми Opus-пакетами и заворачиваем в Ogg.
     *
     * ВНИМАНИЕ (точка уточнения по исходникам): кадрирование сырого Opus-потока
     * от очков (как отделяются пакеты друг от друга — по длине, TOC и т.п.)
     * публично не задокументировано. Здесь применяется консервативная стратегия:
     * весь поток -> один Opus-пакет на страницу при известном framing, иначе
     * сохраняем «как есть». Точный разбор framing'а врезать из manufacturer-original.
     */
    private fun prepareForSave(item: MediaItem, input: InputStream): Pair<String, InputStream> {
        if (item.type != MediaType.AUDIO) {
            return item.name to input
        }

        val raw = input.readBytes()
        // Уже Ogg? — отдать без изменений.
        if (raw.size >= 4 && raw[0] == 'O'.code.toByte() && raw[1] == 'g'.code.toByte() &&
            raw[2] == 'g'.code.toByte() && raw[3] == 'S'.code.toByte()
        ) {
            return item.name to ByteArrayInputStream(raw)
        }

        // Сырые Opus-пакеты -> Ogg. Без точного framing'а кладём поток как один
        // логический пакет на страницу безопасным дроблением; это даёт
        // воспроизводимый контейнер для односегментных записей.
        val packets = splitRawOpus(raw)
        val bos = ByteArrayOutputStream(raw.size + 256)
        OggOpusWriter(bos, channels = 1, inputSampleRate = 16_000).use { writer ->
            for (pkt in packets) {
                // 20 мс кадр Opus @48кГц = 960 сэмплов (типовая длительность кадра).
                writer.writeAudioPacket(pkt, samplesAt48k = 960)
            }
        }
        val outName = item.name.substringBeforeLast('.', item.name) + ".opus"
        return outName to ByteArrayInputStream(bos.toByteArray())
    }

    /**
     * Разбиение сырого потока на Opus-пакеты.
     * TODO(protocol): заменить на точный framing из исходников, если очки
     * отдают пакеты со своими разделителями/длинами. Пока — один пакет.
     */
    private fun splitRawOpus(raw: ByteArray): List<ByteArray> =
        if (raw.isEmpty()) emptyList() else listOf(raw)
}
