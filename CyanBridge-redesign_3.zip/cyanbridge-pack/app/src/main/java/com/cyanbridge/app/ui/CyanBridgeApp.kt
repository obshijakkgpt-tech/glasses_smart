package com.cyanbridge.app.ui

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.cyanbridge.app.ui.nav.Destination
import com.cyanbridge.app.ui.screens.home.HomeScreen
import com.cyanbridge.app.ui.screens.media.MediaScreen
import com.cyanbridge.app.ui.screens.notes.NotesScreen
import com.cyanbridge.app.ui.screens.settings.SettingsScreen
import com.cyanbridge.app.ui.theme.CyanBridgeTheme

@Composable
fun CyanBridgeApp() {
    CyanBridgeTheme {
        val navController = rememberNavController()
        val backStackEntry by navController.currentBackStackEntryAsState()
        val currentRoute = backStackEntry?.destination

        Scaffold(
            bottomBar = {
                NavigationBar {
                    Destination.entries.forEach { dest ->
                        val selected = currentRoute?.hierarchy?.any { it.route == dest.route } == true
                        NavigationBarItem(
                            selected = selected,
                            onClick = {
                                navController.navigate(dest.route) {
                                    popUpTo(navController.graph.findStartDestination().id) {
                                        saveState = true
                                    }
                                    launchSingleTop = true
                                    restoreState = true
                                }
                            },
                            icon = { Icon(dest.icon, contentDescription = dest.label) },
                            label = { Text(dest.label) },
                            colors = NavigationBarItemDefaults.colors(),
                        )
                    }
                }
            },
        ) { padding ->
            NavHost(
                navController = navController,
                startDestination = Destination.HOME.route,
                modifier = Modifier.padding(padding),
            ) {
                composable(Destination.HOME.route) { HomeScreen() }
                composable(Destination.NOTES.route) { NotesScreen() }
                composable(Destination.MEDIA.route) { MediaScreen() }
                composable(Destination.SETTINGS.route) { SettingsScreen() }
            }
        }
    }
}
