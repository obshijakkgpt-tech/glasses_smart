package com.cyanbridge.app.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.TypeConverter
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/** Конвертеры enum <-> String для Room. */
class Converters {
    @TypeConverter fun historyTypeToString(t: HistoryType): String = t.name
    @TypeConverter fun stringToHistoryType(s: String): HistoryType = HistoryType.valueOf(s)
    @TypeConverter fun jobStatusToString(s: JobStatus): String = s.name
    @TypeConverter fun stringToJobStatus(s: String): JobStatus = JobStatus.valueOf(s)
}

@Dao
interface HistoryDao {
    @Query("SELECT * FROM history ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<HistoryEntity>>

    @Query("SELECT * FROM history WHERE type = :type ORDER BY createdAt DESC")
    fun observeByType(type: HistoryType): Flow<List<HistoryEntity>>

    @Insert
    suspend fun insert(item: HistoryEntity): Long

    @Query("DELETE FROM history WHERE id = :id")
    suspend fun delete(id: Long)

    @Query("DELETE FROM history")
    suspend fun clear()
}

@Dao
interface AudioJobDao {
    @Query("SELECT * FROM audio_jobs ORDER BY createdAt DESC LIMIT :limit")
    fun observeRecent(limit: Int = 50): Flow<List<AudioJobEntity>>

    @Query("SELECT * FROM audio_jobs WHERE id = :id")
    fun observe(id: Long): Flow<AudioJobEntity?>

    @Insert
    suspend fun insert(job: AudioJobEntity): Long

    @Update
    suspend fun update(job: AudioJobEntity)

    @Query("UPDATE audio_jobs SET status = :status, updatedAt = :ts WHERE id = :id")
    suspend fun updateStatus(id: Long, status: JobStatus, ts: Long = System.currentTimeMillis())

    @Query("DELETE FROM audio_jobs WHERE status IN ('DONE','FAILED')")
    suspend fun clearFinished()
}
