package com.cyanbridge.app.data.db

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Тип записи истории (как просил пользователь: voice/note/photo/command). */
enum class HistoryType { VOICE, NOTE, PHOTO, COMMAND }

/** Статусы задачи в очереди (чтобы пользователь видел, где зависло). */
enum class JobStatus { UPLOADED, TRANSCRIBING, THINKING, SPEAKING, DONE, FAILED }

/**
 * Запись истории взаимодействий. Минимум по требованию:
 * дата/время, текст запроса, ответ, тип.
 */
@Entity(tableName = "history")
data class HistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val type: HistoryType,
    val request: String,
    val response: String,
    /** Опциональная привязка к медиа/заметке (uri/путь). */
    val attachmentUri: String? = null,
    /** Теги через запятую (для заметок). */
    val tags: String? = null,
)

/**
 * Задача голосового пайплайна. Локальная замена Redis-очереди на старте —
 * простая таблица со статусами, как просил пользователь.
 */
@Entity(tableName = "audio_jobs")
data class AudioJobEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val status: JobStatus = JobStatus.UPLOADED,
    val transcript: String? = null,
    val reply: String? = null,
    val error: String? = null,
)
