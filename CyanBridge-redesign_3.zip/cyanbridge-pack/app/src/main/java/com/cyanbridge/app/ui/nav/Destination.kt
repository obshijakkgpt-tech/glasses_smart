package com.cyanbridge.app.ui.nav

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.ui.graphics.vector.ImageVector

/** Вкладки нижней навигации. */
enum class Destination(
    val route: String,
    val label: String,
    val icon: ImageVector,
) {
    HOME("home", "Главная", Icons.Outlined.Home),
    NOTES("notes", "Заметки", Icons.Outlined.Description),
    MEDIA("media", "Медиа", Icons.Outlined.PhotoLibrary),
    SETTINGS("settings", "Настройки", Icons.Outlined.Settings),
}
