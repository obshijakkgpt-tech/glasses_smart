package com.cyanbridge.app.ble

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.ParcelUuid
import androidx.core.content.ContextCompat
import com.cyanbridge.app.domain.BatteryStatus
import com.cyanbridge.app.domain.ConnectionState
import com.cyanbridge.app.domain.DeviceMode
import com.cyanbridge.app.domain.DeviceState
import com.cyanbridge.app.domain.DiscoveredDevice
import com.cyanbridge.app.domain.GlassesController
import com.cyanbridge.app.domain.MediaCounts
import com.cyanbridge.app.domain.VersionInfo
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * Реальный BLE-контроллер на Android GATT API. Реализует доменный контракт
 * GlassesController. Это "скелет + органы": вся механика BLE (скан, коннект,
 * discovery, подписка, очередь, версия writeCharacteristic) — настоящая.
 *
 * ЕДИНСТВЕННОЕ, чего не хватает до полной работы с железом — реальные байты
 * команд и формат кадров. Они изолированы в HeyCyanProtocol и врезаются туда
 * из исходников ветки manufacturer-original без правок этого файла.
 */
@SuppressLint("MissingPermission")
class NativeBleGlassesController(
    private val context: Context,
) : GlassesController {

    private val btManager = context.getSystemService(BluetoothManager::class.java)
    private val adapter: BluetoothAdapter? get() = btManager?.adapter

    private val _state = MutableStateFlow(DeviceState())
    override val state: StateFlow<DeviceState> = _state.asStateFlow()

    private val _discoveries = MutableSharedFlow<List<DiscoveredDevice>>(replay = 1)
    override val discoveries: Flow<List<DiscoveredDevice>> = _discoveries.asSharedFlow()

    private val found = LinkedHashMap<String, DiscoveredDevice>()
    private var gatt: BluetoothGatt? = null
    private val opQueue = BleOperationQueue()

    private var commandChar: BluetoothGattCharacteristic? = null
    private var notifyChar: BluetoothGattCharacteristic? = null
    private var dataChar: BluetoothGattCharacteristic? = null

    // suspend-продолжения для команд, ждущих ack через onCharacteristicWrite
    private var pendingWrite: ((Boolean) -> Unit)? = null

    // ---------------------------------------------------------------
    // Разрешения
    // ---------------------------------------------------------------
    private fun hasScanPermission(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_SCAN) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED
        }

    private fun hasConnectPermission(): Boolean =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            ContextCompat.checkSelfPermission(context, Manifest.permission.BLUETOOTH_CONNECT) ==
                PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

    // ---------------------------------------------------------------
    // Сканирование
    // ---------------------------------------------------------------
    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val dev = result.device ?: return
            val addr = dev.address ?: return
            val name = if (hasConnectPermission()) dev.name else null
            found[addr] = DiscoveredDevice(addr, name, result.rssi)
            _discoveries.tryEmit(found.values.toList())
        }

        override fun onScanFailed(errorCode: Int) {
            _state.value = _state.value.copy(connection = ConnectionState.DISCONNECTED)
        }
    }

    override fun startScan() {
        val scanner = adapter?.bluetoothLeScanner ?: return
        if (!hasScanPermission()) return
        found.clear()
        _discoveries.tryEmit(emptyList())
        _state.value = _state.value.copy(connection = ConnectionState.SCANNING)

        val filter = ScanFilter.Builder()
            .setServiceUuid(ParcelUuid(HeyCyanProtocol.PRIMARY_SERVICE))
            .build()
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()
        // Фильтр по сервису надёжнее, но некоторые прошивки не рекламируют
        // сервис в advertising пакете -> подстраховка: пустой фильтр + ручной отбор.
        runCatching { scanner.startScan(listOf(filter), settings, scanCallback) }
            .onFailure { runCatching { scanner.startScan(scanCallback) } }
    }

    override fun stopScan() {
        val scanner = adapter?.bluetoothLeScanner
        if (hasScanPermission()) runCatching { scanner?.stopScan(scanCallback) }
        if (_state.value.connection == ConnectionState.SCANNING) {
            _state.value = _state.value.copy(connection = ConnectionState.DISCONNECTED)
        }
    }

    // ---------------------------------------------------------------
    // Подключение
    // ---------------------------------------------------------------
    override suspend fun connect(address: String): Result<Unit> {
        val device = runCatching { adapter?.getRemoteDevice(address) }.getOrNull()
            ?: return Result.failure(IllegalStateException("Устройство $address недоступно"))
        if (!hasConnectPermission()) {
            return Result.failure(SecurityException("Нет разрешения BLUETOOTH_CONNECT"))
        }
        stopScan()
        _state.value = _state.value.copy(
            connection = ConnectionState.CONNECTING,
            device = found[address] ?: DiscoveredDevice(address, null, 0),
        )
        return suspendCancellableCoroutine { cont ->
            connectContinuation = { ok ->
                connectContinuation = null
                if (ok) cont.resume(Result.success(Unit))
                else cont.resume(Result.failure(IllegalStateException("Не удалось подключиться")))
            }
            gatt = device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
            cont.invokeOnCancellation { runCatching { gatt?.disconnect() } }
        }
    }

    private var connectContinuation: ((Boolean) -> Unit)? = null

    override suspend fun disconnect() {
        opQueue.clear()
        if (hasConnectPermission()) runCatching { gatt?.disconnect() }
        _state.value = _state.value.copy(connection = ConnectionState.DISCONNECTING)
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            when (newState) {
                BluetoothProfile.STATE_CONNECTED -> {
                    if (hasConnectPermission()) runCatching { g.discoverServices() }
                }
                BluetoothProfile.STATE_DISCONNECTED -> {
                    opQueue.clear()
                    runCatching { g.close() }
                    gatt = null
                    commandChar = null; notifyChar = null; dataChar = null
                    _state.value = DeviceState()
                    connectContinuation?.invoke(false)
                }
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                connectContinuation?.invoke(false); return
            }
            val service = g.getService(HeyCyanProtocol.PRIMARY_SERVICE)
                ?: g.getService(HeyCyanProtocol.SECONDARY_SERVICE)
            commandChar = service?.getCharacteristic(HeyCyanProtocol.COMMAND_CHARACTERISTIC)
            notifyChar = service?.getCharacteristic(HeyCyanProtocol.NOTIFY_CHARACTERISTIC)
            dataChar = service?.getCharacteristic(HeyCyanProtocol.DATA_CHARACTERISTIC)

            notifyChar?.let { enableNotifications(g, it) }

            _state.value = _state.value.copy(connection = ConnectionState.CONNECTED)
            connectContinuation?.invoke(true)
        }

        override fun onCharacteristicWrite(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int,
        ) {
            pendingWrite?.invoke(status == BluetoothGatt.GATT_SUCCESS)
            pendingWrite = null
            opQueue.completed()
        }

        override fun onDescriptorWrite(
            g: BluetoothGatt,
            descriptor: BluetoothGattDescriptor,
            status: Int,
        ) {
            opQueue.completed()
        }

        // API < 33
        @Deprecated("Deprecated in API 33")
        @Suppress("DEPRECATION")
        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
        ) {
            handleNotification(characteristic.value)
        }

        // API >= 33
        override fun onCharacteristicChanged(
            g: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray,
        ) {
            handleNotification(value)
        }
    }

    private fun enableNotifications(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
        opQueue.enqueue {
            if (!hasConnectPermission()) { opQueue.completed(); return@enqueue }
            g.setCharacteristicNotification(ch, true)
            val cccd = ch.getDescriptor(HeyCyanProtocol.CCCD)
            if (cccd == null) { opQueue.completed(); return@enqueue }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                g.writeDescriptor(cccd, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
            } else {
                @Suppress("DEPRECATION")
                run {
                    cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    g.writeDescriptor(cccd)
                }
            }
        }
    }

    private fun handleNotification(bytes: ByteArray?) {
        if (bytes == null) return
        when (val ev = HeyCyanProtocol.decodeNotification(bytes)) {
            is DeviceEvent.Battery ->
                _state.value = _state.value.copy(
                    battery = BatteryStatus(ev.percent, ev.charging),
                )
            is DeviceEvent.Media ->
                _state.value = _state.value.copy(
                    media = MediaCounts(ev.photos, ev.videos, ev.audios),
                )
            is DeviceEvent.Version ->
                _state.value = _state.value.copy(
                    version = VersionInfo(ev.hardware, ev.firmware, ev.hardwareWifi, ev.firmwareWifi),
                )
            is DeviceEvent.ModeChanged ->
                _state.value = _state.value.copy(activeMode = ev.mode)
            is DeviceEvent.Unknown -> Unit // лог можно добавить
        }
    }

    // ---------------------------------------------------------------
    // Запись команды (с версионной вилкой API 33)
    // ---------------------------------------------------------------
    private suspend fun writeCommand(payload: ByteArray): Result<Unit> {
        val g = gatt ?: return Result.failure(IllegalStateException("Нет соединения"))
        val ch = commandChar ?: return Result.failure(IllegalStateException("Нет command-характеристики"))
        if (!hasConnectPermission()) return Result.failure(SecurityException("Нет BLUETOOTH_CONNECT"))

        return suspendCancellableCoroutine { cont ->
            pendingWrite = { ok ->
                if (ok) cont.resume(Result.success(Unit))
                else cont.resume(Result.failure(IllegalStateException("Запись не удалась")))
            }
            opQueue.enqueue {
                val type = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    g.writeCharacteristic(ch, payload, type)
                } else {
                    @Suppress("DEPRECATION")
                    run {
                        ch.value = payload
                        ch.writeType = type
                        g.writeCharacteristic(ch)
                    }
                }
            }
        }
    }

    // ---------------------------------------------------------------
    // Команды управления (байты берутся из HeyCyanProtocol)
    // ---------------------------------------------------------------
    override suspend fun takePhoto(): Result<Unit> =
        runCommand { HeyCyanProtocol.encodeSetMode(DeviceMode.PHOTO) }

    override suspend fun startVideo(): Result<Unit> =
        runCommand { HeyCyanProtocol.encodeSetMode(DeviceMode.VIDEO) }

    override suspend fun stopVideo(): Result<Unit> =
        runCommand { HeyCyanProtocol.encodeSetMode(DeviceMode.VIDEO_STOP) }

    override suspend fun startAudio(): Result<Unit> =
        runCommand { HeyCyanProtocol.encodeSetMode(DeviceMode.AUDIO) }

    override suspend fun stopAudio(): Result<Unit> =
        runCommand { HeyCyanProtocol.encodeSetMode(DeviceMode.AUDIO_STOP) }

    override suspend fun triggerAiPhoto(): Result<Unit> =
        runCommand { HeyCyanProtocol.encodeSetMode(DeviceMode.AI_PHOTO) }

    override suspend fun refreshBattery(): Result<BatteryStatus> =
        runCommand { HeyCyanProtocol.encodeGetBattery() }.map { _state.value.battery }

    override suspend fun refreshMediaCounts(): Result<MediaCounts> =
        runCommand { HeyCyanProtocol.encodeGetMediaCounts() }.map { _state.value.media }

    override suspend fun refreshVersionInfo(): Result<VersionInfo> =
        runCommand { HeyCyanProtocol.encodeGetVersionInfo() }.map { _state.value.version }

    override suspend fun enterTransferMode(): Result<String> {
        return runCommand { HeyCyanProtocol.encodeSetMode(DeviceMode.TRANSFER) }
            .map {
                // IP точки доступа очков подбирается в net-слое (кандидаты).
                "http://192.168.43.1"
            }
    }

    private inline fun encodeSafely(block: () -> ByteArray): Result<ByteArray> =
        runCatching(block)

    private suspend fun runCommand(encode: () -> ByteArray): Result<Unit> {
        val payload = encodeSafely(encode).getOrElse { return Result.failure(it) }
        return writeCommand(payload)
    }

    override fun release() {
        opQueue.clear()
        if (hasConnectPermission()) runCatching { gatt?.close() }
        gatt = null
    }
}
