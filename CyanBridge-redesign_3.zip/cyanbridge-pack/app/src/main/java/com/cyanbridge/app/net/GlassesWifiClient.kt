package com.cyanbridge.app.net

import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.TimeUnit

/** Прогресс скачивания одного файла. */
data class DownloadProgress(
    val item: MediaItem,
    val bytesRead: Long,
    val totalBytes: Long?,
    val index: Int,
    val count: Int,
)

/** Результат полной синхронизации. */
sealed interface SyncEvent {
    data class BaseUrlResolved(val baseUrl: String) : SyncEvent
    data class ManifestLoaded(val items: List<MediaItem>) : SyncEvent
    data class Progress(val progress: DownloadProgress) : SyncEvent
    data class FileSaved(val item: MediaItem, val savedUri: String) : SyncEvent
    data class Failed(val item: MediaItem?, val error: String) : SyncEvent
    data object Completed : SyncEvent
}

/**
 * HTTP-клиент для выгрузки медиа с очков в режиме Transfer.
 *
 * Реальные эндпоинты (из release notes апстрима v1.0.2):
 *   GET <base>/files/media.config   — манифест
 *   GET <base>/files/<name>          — файл (jpg/mp4/opus)
 *
 * IP точки доступа очков заранее не фиксирован — перебираем известные
 * кандидаты SoftAP/WiFi-Direct, пока манифест не ответит.
 */
class GlassesWifiClient(
    private val client: OkHttpClient = defaultClient(),
) {
    /** Кандидаты базового адреса точки доступа очков. */
    private val candidateHosts = listOf(
        "192.168.43.1",   // частый SoftAP
        "192.168.49.1",   // WiFi Direct (P2P) group owner
        "192.168.4.1",    // частый ESP/SoftAP
        "192.168.1.1",
    )

    /** Найти живой базовый URL, на котором отвечает media.config. */
    suspend fun resolveBaseUrl(): String? {
        for (host in candidateHosts) {
            val url = "http://$host/files/media.config"
            val req = Request.Builder().url(url).get().build()
            val ok = runCatching {
                client.newCall(req).execute().use { it.isSuccessful }
            }.getOrDefault(false)
            if (ok) return "http://$host"
        }
        return null
    }

    /** Скачать и распарсить манифест. */
    suspend fun fetchManifest(baseUrl: String): List<MediaItem> {
        val req = Request.Builder().url("$baseUrl/files/media.config").get().build()
        client.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) throw IOException("media.config: HTTP ${resp.code}")
            val body = resp.body?.string() ?: throw IOException("Пустой манифест")
            return MediaManifestParser.parse(body)
        }
    }

    /**
     * Открыть поток файла для скачивания. Возвращает (InputStream, длина?).
     * Закрытие потока — на стороне вызывающего.
     */
    fun openFile(baseUrl: String, item: MediaItem): Pair<InputStream, Long?> {
        val req = Request.Builder().url("$baseUrl${item.downloadPath}").get().build()
        val resp = client.newCall(req).execute()
        if (!resp.isSuccessful) {
            resp.close()
            throw IOException("${item.name}: HTTP ${resp.code}")
        }
        val body = resp.body ?: run { resp.close(); throw IOException("Пустое тело ${item.name}") }
        val len = body.contentLength().takeIf { it >= 0 }
        return body.byteStream() to len
    }

    private companion object {
        fun defaultClient(): OkHttpClient = OkHttpClient.Builder()
            // Точка доступа очков медленная — щедрые таймауты.
            .connectTimeout(5, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }
}
