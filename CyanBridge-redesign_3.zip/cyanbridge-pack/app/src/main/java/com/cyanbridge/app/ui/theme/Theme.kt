package com.cyanbridge.app.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

/**
 * Дополнительные акценты, которых нет в стандартной Material3 ColorScheme
 * (цвета по типам медиа). Доступны через LocalCbAccents.current.
 */
data class CbAccents(
    val video: Color = CbVideo,
    val audio: Color = CbAudio,
    val ai: Color = CbAi,
    val cyan: Color = CbCyan,
    val success: Color = CbSuccess,
)

val LocalCbAccents = staticCompositionLocalOf { CbAccents() }

private val CbDarkColors = darkColorScheme(
    primary = CbCyan,
    onPrimary = CbOnCyan,
    primaryContainer = CbCyanDim,
    onPrimaryContainer = CbOnCyan,
    secondary = CbAi,
    onSecondary = CbOnCyan,
    tertiary = CbVideo,
    onTertiary = CbOnCyan,
    background = CbBackground,
    onBackground = CbTextPrimary,
    surface = CbSurface,
    onSurface = CbTextPrimary,
    surfaceVariant = CbSurfaceVariant,
    onSurfaceVariant = CbTextSecondary,
    outline = CbOutline,
    outlineVariant = CbOutlineVariant,
    error = CbError,
    onError = CbOnCyan,
)

// Светлая схема — на будущее (бренд тёмный, но Material требует обе).
private val CbLightColors = lightColorScheme(
    primary = CbCyanDim,
    onPrimary = Color.White,
    background = Color(0xFFF7F9FA),
    onBackground = Color(0xFF0B0F12),
    surface = Color.White,
    onSurface = Color(0xFF0B0F12),
)

@Composable
fun CyanBridgeTheme(
    darkTheme: Boolean = true,            // бренд по умолчанию тёмный
    dynamicColor: Boolean = false,        // Material You; off => фирменный неон
    content: @Composable () -> Unit,
) {
    val context = LocalContext.current
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            if (darkTheme) dynamicDarkColorScheme(context)
            else dynamicLightColorSchemeCompat(context, darkTheme)
        }
        darkTheme -> CbDarkColors
        else -> CbLightColors
    }

    val view = LocalView.current
    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            WindowCompat.setDecorFitsSystemWindows(window, false)
            val light = colorScheme.background.luminance() > 0.5f
            val controller = WindowCompat.getInsetsController(window, view)
            controller.isAppearanceLightStatusBars = light
            controller.isAppearanceLightNavigationBars = light
        }
    }

    CompositionLocalProvider(LocalCbAccents provides CbAccents()) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = CbTypography,
            content = content,
        )
    }
}

private fun dynamicLightColorSchemeCompat(
    context: android.content.Context,
    darkTheme: Boolean,
) = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
    androidx.compose.material3.dynamicLightColorScheme(context)
} else {
    CbLightColors
}
