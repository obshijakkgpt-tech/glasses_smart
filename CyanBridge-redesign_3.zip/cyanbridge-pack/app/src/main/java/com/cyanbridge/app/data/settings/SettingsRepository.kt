package com.cyanbridge.app.data.settings

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "cyan_settings")

/** Режим устройства: телефон (без очков) или реальные очки. */
enum class DeviceModeSetting { FAKE, NATIVE }

/** Снимок всех настроек приложения. */
data class AppSettings(
    val hermesUrl: String = "",
    val hermesApiKey: String = "",
    val openRouterModel: String = "hermes-agent",
    val ttsVoiceLanguage: String = "auto",
    val sttLanguage: String = "auto",
    val deviceMode: DeviceModeSetting = DeviceModeSetting.FAKE,
)

class SettingsRepository(private val context: Context) {

    private object Keys {
        val HERMES_URL = stringPreferencesKey("hermes_url")
        val HERMES_KEY = stringPreferencesKey("hermes_api_key")
        val MODEL = stringPreferencesKey("openrouter_model")
        val TTS_LANG = stringPreferencesKey("tts_voice_language")
        val STT_LANG = stringPreferencesKey("stt_language")
        val MODE = stringPreferencesKey("device_mode")
    }

    val settings: Flow<AppSettings> = context.dataStore.data.map { p ->
        AppSettings(
            hermesUrl = p[Keys.HERMES_URL].orEmpty(),
            hermesApiKey = p[Keys.HERMES_KEY].orEmpty(),
            openRouterModel = p[Keys.MODEL] ?: "hermes-agent",
            ttsVoiceLanguage = p[Keys.TTS_LANG] ?: "auto",
            sttLanguage = p[Keys.STT_LANG] ?: "auto",
            deviceMode = runCatching {
                DeviceModeSetting.valueOf(p[Keys.MODE] ?: DeviceModeSetting.FAKE.name)
            }.getOrDefault(DeviceModeSetting.FAKE),
        )
    }

    suspend fun update(transform: (AppSettings) -> AppSettings) {
        context.dataStore.edit { p ->
            val current = AppSettings(
                hermesUrl = p[Keys.HERMES_URL].orEmpty(),
                hermesApiKey = p[Keys.HERMES_KEY].orEmpty(),
                openRouterModel = p[Keys.MODEL] ?: "hermes-agent",
                ttsVoiceLanguage = p[Keys.TTS_LANG] ?: "auto",
                sttLanguage = p[Keys.STT_LANG] ?: "auto",
                deviceMode = runCatching {
                    DeviceModeSetting.valueOf(p[Keys.MODE] ?: DeviceModeSetting.FAKE.name)
                }.getOrDefault(DeviceModeSetting.FAKE),
            )
            val next = transform(current)
            p[Keys.HERMES_URL] = next.hermesUrl
            p[Keys.HERMES_KEY] = next.hermesApiKey
            p[Keys.MODEL] = next.openRouterModel
            p[Keys.TTS_LANG] = next.ttsVoiceLanguage
            p[Keys.STT_LANG] = next.sttLanguage
            p[Keys.MODE] = next.deviceMode.name
        }
    }
}
