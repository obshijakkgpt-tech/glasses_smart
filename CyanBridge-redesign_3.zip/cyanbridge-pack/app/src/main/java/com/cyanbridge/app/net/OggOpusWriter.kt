package com.cyanbridge.app.net

import java.io.OutputStream

/**
 * Упаковка «сырых» Opus-пакетов (как их отдают очки HeyCyan) в корректный
 * Ogg/Opus контейнер по RFC 7845. Без этого многие .opus-записи с устройства
 * не воспроизводятся (так описано в release notes апстрима v1.0.2).
 *
 * Это полноценная реализация, а не заглушка: пишет OpusHead, OpusTags,
 * страницы с lacing-таблицей, granule position при 48 кГц и корректный
 * Ogg-CRC32 (полином 0x04C11DB7, без рефлексии, init 0).
 *
 * Использование:
 *   OggOpusWriter(out, channels = 1, inputSampleRate = 16000).use { w ->
 *       rawPackets.forEach { w.writeAudioPacket(it, samplesInPacket) }
 *   }
 */
class OggOpusWriter(
    private val out: OutputStream,
    private val channels: Int = 1,
    private val inputSampleRate: Int = 48_000,
    private val preSkip: Int = 3_840,            // 80 мс при 48кГц — безопасно
    private val serial: Int = (System.nanoTime() and 0xFFFFFFFFL).toInt(),
) : AutoCloseable {

    private var pageSeq = 0
    private var granule = 0L
    private var headerWritten = false
    private var closed = false

    /** Записать заголовки OpusHead + OpusTags (вызывается лениво). */
    private fun ensureHeaders() {
        if (headerWritten) return
        writePage(buildOpusHead(), granulePos = 0, bos = true, eos = false)
        writePage(buildOpusTags(), granulePos = 0, bos = false, eos = false)
        headerWritten = true
    }

    /**
     * Записать один Opus-аудиопакет.
     * @param packet сырой Opus-пакет (TOC + frame data).
     * @param samplesAt48k число PCM-сэмплов в пакете, пересчитанное к 48кГц.
     *   Если неизвестно — передать оценку; на воспроизводимость не влияет,
     *   влияет лишь на длительность/seek.
     */
    fun writeAudioPacket(packet: ByteArray, samplesAt48k: Int) {
        check(!closed) { "writer закрыт" }
        ensureHeaders()
        granule += samplesAt48k
        writePage(packet, granulePos = granule, bos = false, eos = false)
    }

    override fun close() {
        if (closed) return
        ensureHeaders()
        // Финальная пустая страница с EOS, чтобы корректно завершить поток.
        writePage(ByteArray(0), granulePos = granule, bos = false, eos = true)
        out.flush()
        closed = true
    }

    // --- OpusHead (RFC 7845 §5.1) ---
    private fun buildOpusHead(): ByteArray {
        val b = ByteArrayBuilder()
        b.bytes("OpusHead".toByteArray(Charsets.US_ASCII)) // magic
        b.u8(1)                                            // version
        b.u8(channels)                                     // channel count
        b.u16le(preSkip)                                   // pre-skip
        b.u32le(inputSampleRate)                           // input sample rate
        b.u16le(0)                                         // output gain (Q7.8) = 0
        b.u8(0)                                            // channel mapping family 0
        return b.toByteArray()
    }

    // --- OpusTags (RFC 7845 §5.2) ---
    private fun buildOpusTags(): ByteArray {
        val vendor = "CyanBridge".toByteArray(Charsets.UTF_8)
        val b = ByteArrayBuilder()
        b.bytes("OpusTags".toByteArray(Charsets.US_ASCII))
        b.u32le(vendor.size)
        b.bytes(vendor)
        b.u32le(0)  // user comment list length = 0
        return b.toByteArray()
    }

    /**
     * Записать одну Ogg-страницу. Для простоты — один пакет на страницу
     * (валидно по спецификации). Пакеты до 255*255 байт разбиваются по
     * lacing-правилам.
     */
    private fun writePage(packet: ByteArray, granulePos: Long, bos: Boolean, eos: Boolean) {
        // Лейсинг: пакет дробится на сегменты по 255 байт, последний сегмент
        // < 255 (если длина кратна 255 — нужен завершающий 0-сегмент).
        val segments = ArrayList<Int>()
        var remaining = packet.size
        while (remaining >= 255) { segments.add(255); remaining -= 255 }
        segments.add(remaining) // финальный сегмент (может быть 0)

        // Ограничение: одна страница вмещает максимум 255 сегментов.
        // Сырые Opus-пакеты с очков заведомо короче 255*255 — не дробим на
        // несколько страниц.
        require(segments.size <= 255) { "пакет слишком большой для одной страницы" }

        var headerType = 0
        if (bos) headerType = headerType or 0x02
        if (eos) headerType = headerType or 0x04

        val header = ByteArrayBuilder()
        header.bytes("OggS".toByteArray(Charsets.US_ASCII)) // capture pattern
        header.u8(0)                                        // stream structure version
        header.u8(headerType)                               // header type flag
        header.u64le(granulePos)                            // granule position
        header.u32le(serial)                                // stream serial
        header.u32le(pageSeq++)                             // page sequence
        header.u32le(0)                                     // CRC placeholder
        header.u8(segments.size)                            // page segments
        segments.forEach { header.u8(it) }                  // lacing table

        val headerBytes = header.toByteArray()
        val full = ByteArray(headerBytes.size + packet.size)
        System.arraycopy(headerBytes, 0, full, 0, headerBytes.size)
        System.arraycopy(packet, 0, full, headerBytes.size, packet.size)

        // CRC32 (Ogg) по всей странице с нулевым полем CRC, затем вписываем.
        val crc = oggCrc32(full)
        full[22] = (crc and 0xFF).toByte()
        full[23] = ((crc ushr 8) and 0xFF).toByte()
        full[24] = ((crc ushr 16) and 0xFF).toByte()
        full[25] = ((crc ushr 24) and 0xFF).toByte()

        out.write(full)
    }

    // --- Ogg CRC32: poly 0x04C11DB7, без рефлексии входа/выхода, init 0 ---
    private fun oggCrc32(data: ByteArray): Int {
        var crc = 0
        for (byte in data) {
            crc = (crc shl 8) xor CRC_TABLE[((crc ushr 24) and 0xFF) xor (byte.toInt() and 0xFF)]
        }
        return crc
    }

    private companion object {
        val CRC_TABLE = IntArray(256).also { table ->
            for (i in 0 until 256) {
                var r = i shl 24
                repeat(8) {
                    r = if ((r and 0x80000000.toInt()) != 0) (r shl 1) xor 0x04C11DB7 else r shl 1
                }
                table[i] = r
            }
        }
    }
}

/** Минимальный билдер байтовых массивов с little-endian примитивами. */
private class ByteArrayBuilder {
    private val buf = ArrayList<Byte>(64)
    fun u8(v: Int) { buf.add((v and 0xFF).toByte()) }
    fun u16le(v: Int) { u8(v); u8(v ushr 8) }
    fun u32le(v: Int) { u8(v); u8(v ushr 8); u8(v ushr 16); u8(v ushr 24) }
    fun u64le(v: Long) { for (i in 0 until 8) u8(((v ushr (i * 8)) and 0xFF).toInt()) }
    fun bytes(b: ByteArray) { for (x in b) buf.add(x) }
    fun toByteArray(): ByteArray = buf.toByteArray()
}
