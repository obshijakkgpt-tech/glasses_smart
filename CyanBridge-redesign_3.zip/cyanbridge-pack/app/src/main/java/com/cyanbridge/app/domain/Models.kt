package com.cyanbridge.app.domain

/**
 * Режимы работы очков HeyCyan.
 * Зеркалит QCOperatorDeviceMode из оригинального QCSDK (порядок сохранён —
 * важно, если ordinal маппится на байт команды в реализации поверх .aar).
 */
enum class DeviceMode {
    PHOTO,        // QCOperatorDeviceModePhoto
    VIDEO,        // QCOperatorDeviceModeVideo
    VIDEO_STOP,   // QCOperatorDeviceModeVideoStop
    AUDIO,        // QCOperatorDeviceModeAudio
    AUDIO_STOP,   // QCOperatorDeviceModeAudioStop
    AI_PHOTO,     // QCOperatorDeviceModeAIPhoto
    TRANSFER,     // QCOperatorDeviceModeTransfer (поднять WiFi для выгрузки медиа)
}

/** Стадия BLE-подключения к очкам. */
enum class ConnectionState {
    DISCONNECTED,
    SCANNING,
    CONNECTING,
    CONNECTED,
    DISCONNECTING,
}

/** Найденное при сканировании устройство. */
data class DiscoveredDevice(
    val address: String,   // MAC
    val name: String?,     // рекламируемое имя (может быть null)
    val rssi: Int,         // мощность сигнала, dBm
)

/** Счётчики медиа на устройстве (из getDeviceMedia). */
data class MediaCounts(
    val photos: Int = 0,
    val videos: Int = 0,
    val audios: Int = 0,
) {
    val total: Int get() = photos + videos + audios
}

/** Состояние батареи (из getDeviceBattery). */
data class BatteryStatus(
    val percent: Int = 0,
    val charging: Boolean = false,
)

/** Версии прошивки/железа (из getDeviceVersionInfo). */
data class VersionInfo(
    val hardware: String? = null,
    val firmware: String? = null,
    val hardwareWifi: String? = null,
    val firmwareWifi: String? = null,
)

/**
 * Полное наблюдаемое состояние подключённого устройства.
 * UI рендерится как функция от этого состояния (Compose).
 */
data class DeviceState(
    val connection: ConnectionState = ConnectionState.DISCONNECTED,
    val device: DiscoveredDevice? = null,
    val battery: BatteryStatus = BatteryStatus(),
    val media: MediaCounts = MediaCounts(),
    val version: VersionInfo = VersionInfo(),
    val activeMode: DeviceMode? = null,
)
