package com.cyanbridge.app.ui.screens.home

import android.Manifest
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.cyanbridge.app.ui.theme.LocalCbAccents
import com.cyanbridge.app.voice.PipelineState

@Composable
fun HomeScreen(vm: VoiceViewModel = viewModel()) {
    val state by vm.ui.collectAsStateWithLifecycle()
    val accents = LocalCbAccents.current

    val micPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission(),
    ) { granted -> if (granted) vm.startTalking() }

    LaunchedEffect(Unit) { vm.checkServer() }

    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // --- Статус-строка: сервер / очки ---
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                StatusPill(
                    label = serverLabel(state.serverStatus),
                    color = serverColor(state.serverStatus, accents.success),
                    modifier = Modifier.weight(1f),
                )
                StatusPill(
                    label = "Очки: не подключены",
                    color = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.weight(1f),
                )
            }

            Spacer(Modifier.height(40.dp))

            // --- Индикатор состояния пайплайна ---
            Text(
                text = state.pipeline.label,
                style = MaterialTheme.typography.headlineMedium,
                color = if (state.pipeline == PipelineState.ERROR)
                    MaterialTheme.colorScheme.error else accents.cyan,
            )
            Spacer(Modifier.height(8.dp))
            Text(
                text = pipelineHint(state.pipeline),
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )

            Spacer(Modifier.height(36.dp))

            // --- Большая кнопка "Говорить" ---
            TalkButton(
                active = state.pipeline == PipelineState.LISTENING,
                accent = accents.cyan,
                onTap = { micPermission.launch(Manifest.permission.RECORD_AUDIO) },
            )

            Spacer(Modifier.height(36.dp))

            // --- Последний диалог ---
            if (state.partialTranscript.isNotBlank() &&
                state.pipeline == PipelineState.LISTENING
            ) {
                DialogCard("Слышу…", state.partialTranscript, accents.cyan)
            }
            if (state.lastTranscript.isNotBlank()) {
                DialogCard("Вы", state.lastTranscript, MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
            }
            if (state.lastReply.isNotBlank()) {
                DialogCard("Ассистент", state.lastReply, accents.cyan)
            }

            state.errorMessage?.let {
                Spacer(Modifier.height(16.dp))
                Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
            }
        }
    }
}

@Composable
private fun TalkButton(active: Boolean, accent: Color, onTap: () -> Unit) {
    val transition = rememberInfiniteTransition(label = "pulse")
    val pulse by transition.animateFloat(
        initialValue = 1f,
        targetValue = if (active) 1.12f else 1f,
        animationSpec = infiniteRepeatable(tween(800), RepeatMode.Reverse),
        label = "scale",
    )
    Box(
        modifier = Modifier
            .size(160.dp)
            .scale(pulse)
            .clip(CircleShape)
            .background(if (active) accent else accent.copy(alpha = 0.18f))
            .pointerInput(Unit) {
                androidx.compose.foundation.gestures.detectTapGestures(onTap = { onTap() })
            },
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            imageVector = Icons.Filled.Mic,
            contentDescription = "Говорить",
            tint = if (active) Color(0xFF001014) else accent,
            modifier = Modifier.size(64.dp),
        )
    }
}

@Composable
private fun StatusPill(label: String, color: Color, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(999.dp),
        color = MaterialTheme.colorScheme.surface,
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(color),
            )
            Text(
                label,
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
            )
        }
    }
}

@Composable
private fun DialogCard(speaker: String, text: String, accent: Color) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(
                speaker.uppercase(),
                style = MaterialTheme.typography.labelSmall,
                color = accent,
                fontWeight = FontWeight.Medium,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                text,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
            )
        }
    }
}

private fun serverLabel(s: ServerStatus): String = when (s) {
    ServerStatus.UNKNOWN -> "Сервер: —"
    ServerStatus.CHECKING -> "Сервер: проверка…"
    ServerStatus.ONLINE -> "Сервер: онлайн"
    ServerStatus.OFFLINE -> "Сервер: офлайн"
}

private fun serverColor(s: ServerStatus, success: Color): Color = when (s) {
    ServerStatus.ONLINE -> success
    ServerStatus.OFFLINE -> Color(0xFFFF5449)
    else -> Color(0xFF8A9199)
}

private fun pipelineHint(s: PipelineState): String = when (s) {
    PipelineState.IDLE -> "Нажмите кнопку и говорите"
    PipelineState.LISTENING -> "Говорите…"
    PipelineState.TRANSCRIBING -> "Обрабатываю речь"
    PipelineState.THINKING -> "Ассистент думает"
    PipelineState.SPEAKING -> "Воспроизвожу ответ"
    PipelineState.ERROR -> "Что-то пошло не так"
}
