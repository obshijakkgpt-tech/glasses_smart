package com.cyanbridge.app

import android.app.Application

class CyanBridgeApp : Application() {
    override fun onCreate() {
        super.onCreate()
    }
}
