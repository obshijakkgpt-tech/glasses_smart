package com.cyanbridge.app.data

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.cyanbridge.app.net.MediaItem
import com.cyanbridge.app.net.MediaType
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream

/**
 * Сохранение медиа в системную галерею в папку DCIM/CyanBridge — так же, как
 * апстрим (release notes v1.0.2: "Save photos/videos/audio via MediaStore into
 * DCIM/CyanBridge").
 *
 * Вилка по версии: API 29+ — scoped storage через RELATIVE_PATH + IS_PENDING;
 * API 26–28 — прямой путь во внешнее хранилище (нужно WRITE_EXTERNAL_STORAGE,
 * объявлено в манифесте с maxSdkVersion=28).
 */
class MediaStoreSaver(private val context: Context) {

    private val subDir = "CyanBridge"

    /**
     * Сохранить поток в галерею. [outName] — итоговое имя файла (для opus,
     * завёрнутого в Ogg, расширение остаётся .opus — это валидный Ogg/Opus).
     * Возвращает URI/путь сохранённого файла строкой.
     */
    fun save(item: MediaItem, outName: String, source: InputStream): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            saveScoped(item, outName, source)
        } else {
            saveLegacy(item, outName, source)
        }
    }

    private fun saveScoped(item: MediaItem, outName: String, source: InputStream): String {
        val resolver = context.contentResolver
        val (collection, relativeBase, values) = when (item.type) {
            MediaType.PHOTO -> Triple(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                Environment.DIRECTORY_DCIM,
                ContentValues().apply { put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg") },
            )
            MediaType.VIDEO -> Triple(
                MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                Environment.DIRECTORY_DCIM,
                ContentValues().apply { put(MediaStore.Video.Media.MIME_TYPE, "video/mp4") },
            )
            else -> Triple(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                Environment.DIRECTORY_DCIM,
                ContentValues().apply { put(MediaStore.Audio.Media.MIME_TYPE, "audio/ogg") },
            )
        }

        values.apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, outName)
            put(MediaStore.MediaColumns.RELATIVE_PATH, "$relativeBase/$subDir")
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }

        val uri = resolver.insert(collection, values)
            ?: error("MediaStore.insert вернул null для $outName")

        resolver.openOutputStream(uri).use { out ->
            checkNotNull(out) { "Не удалось открыть OutputStream для $outName" }
            source.copyTo(out)
        }

        val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
        resolver.update(uri, done, null, null)
        return uri.toString()
    }

    @Suppress("DEPRECATION")
    private fun saveLegacy(item: MediaItem, outName: String, source: InputStream): String {
        val dcim = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM)
        val dir = File(dcim, subDir).apply { if (!exists()) mkdirs() }
        val outFile = File(dir, outName)
        FileOutputStream(outFile).use { out: OutputStream -> source.copyTo(out) }

        // Уведомить MediaScanner, чтобы файл появился в галерее.
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DATA, outFile.absolutePath)
            put(MediaStore.MediaColumns.DISPLAY_NAME, outName)
            when (item.type) {
                MediaType.PHOTO -> put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                MediaType.VIDEO -> put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                else -> put(MediaStore.Audio.Media.MIME_TYPE, "audio/ogg")
            }
        }
        val collection = when (item.type) {
            MediaType.PHOTO -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            MediaType.VIDEO -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            else -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        }
        context.contentResolver.insert(collection, values)
        return outFile.absolutePath
    }
}
