package com.cyanbridge.app.voice

import com.cyanbridge.app.data.db.AudioJobDao
import com.cyanbridge.app.data.db.AudioJobEntity
import com.cyanbridge.app.data.db.HistoryDao
import com.cyanbridge.app.data.db.HistoryEntity
import com.cyanbridge.app.data.db.HistoryType
import com.cyanbridge.app.data.db.JobStatus
import com.cyanbridge.app.hermes.HermesClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first

/**
 * Полный голосовой цикл: распознанный текст -> Hermes -> озвучка.
 *
 * Состояние пайплайна публикуется в [state] и отражается в UI ("Слушаю…",
 * "Думаю…" и т.д.) — это прямое средство против UX-задержек. Каждый прогон
 * заводит запись в audio_jobs (видно, где зависло) и, при успехе, в history.
 *
 * STT-часть (микрофон) живёт в UI/VM, т.к. требует жизненного цикла и
 * partial-результатов; сюда приходит уже финальный transcript.
 */
class VoicePipeline(
    private val hermes: HermesClient,
    private val tts: PhoneTextToSpeech,
    private val historyDao: HistoryDao,
    private val audioJobDao: AudioJobDao,
    private val systemPrompt: String? = DEFAULT_SYSTEM_PROMPT,
) {
    private val _state = MutableStateFlow(PipelineState.IDLE)
    val state: StateFlow<PipelineState> = _state.asStateFlow()

    private val _lastTranscript = MutableStateFlow("")
    val lastTranscript: StateFlow<String> = _lastTranscript.asStateFlow()

    private val _lastReply = MutableStateFlow("")
    val lastReply: StateFlow<String> = _lastReply.asStateFlow()

    fun onListening() { _state.value = PipelineState.LISTENING }
    fun onTranscribing() { _state.value = PipelineState.TRANSCRIBING }

    /**
     * Обработать финальный распознанный текст: отправить в Hermes, озвучить
     * ответ, записать историю. Возвращает текст ответа.
     */
    suspend fun handleTranscript(transcript: String, speak: Boolean = true): Result<String> {
        _lastTranscript.value = transcript
        val jobId = audioJobDao.insert(
            AudioJobEntity(status = JobStatus.THINKING, transcript = transcript),
        )

        _state.value = PipelineState.THINKING
        val replyResult = hermes.chat(userText = transcript, systemPrompt = systemPrompt)

        return replyResult.fold(
            onSuccess = { reply ->
                _lastReply.value = reply
                audioJobDao.update(
                    currentJob(jobId).copy(status = JobStatus.SPEAKING, reply = reply),
                )

                if (speak) {
                    _state.value = PipelineState.SPEAKING
                    tts.speak(reply)
                }

                historyDao.insert(
                    HistoryEntity(
                        type = HistoryType.VOICE,
                        request = transcript,
                        response = reply,
                    ),
                )
                audioJobDao.updateStatus(jobId, JobStatus.DONE)
                _state.value = PipelineState.IDLE
                Result.success(reply)
            },
            onFailure = { err ->
                audioJobDao.update(
                    currentJob(jobId).copy(status = JobStatus.FAILED, error = err.message),
                )
                _state.value = PipelineState.ERROR
                Result.failure(err)
            },
        )
    }

    /** Обработать ошибку STT (микрофон не распознал и т.п.). */
    suspend fun onSttError(message: String) {
        audioJobDao.insert(
            AudioJobEntity(status = JobStatus.FAILED, error = message),
        )
        _state.value = PipelineState.ERROR
    }

    fun resetToIdle() { _state.value = PipelineState.IDLE }

    private suspend fun currentJob(id: Long): AudioJobEntity =
        audioJobDao.observe(id).first()
            ?: AudioJobEntity(id = id)

    companion object {
        const val DEFAULT_SYSTEM_PROMPT =
            "Ты — голосовой ассистент умных очков. Отвечай кратко, " +
                "одним-двумя предложениями, пригодными для озвучивания."
    }
}
