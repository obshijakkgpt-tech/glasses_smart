package com.cyanbridge.app.ui.theme

import androidx.compose.ui.graphics.Color

// ============================================================
// Палитра CyanBridge — тёмный минимализм с неон-акцентами.
// Значения взяты из утверждённого концепта (см. PROJECT_MEMORY.md).
// ============================================================

// Фоны и поверхности
val CbBackground = Color(0xFF0B0F12)   // основной фон (почти чёрный)
val CbSurface = Color(0xFF131A1F)      // карточки
val CbSurfaceVariant = Color(0xFF161E25)
val CbOutline = Color(0xFF1F2730)      // обводки
val CbOutlineVariant = Color(0xFF2A333D)

// Неон-акцент бренда
val CbCyan = Color(0xFF00E5FF)
val CbCyanDim = Color(0xFF00B8CC)
val CbOnCyan = Color(0xFF001014)       // текст на неоне

// Акценты по типам медиа
val CbVideo = Color(0xFFFF5A96)        // розовый
val CbAudio = Color(0xFFFFB238)        // янтарный
val CbAi = Color(0xFFA878FF)           // фиолетовый

// Текст
val CbTextPrimary = Color(0xFFE8EAED)
val CbTextSecondary = Color(0xFF8A9199)
val CbTextDisabled = Color(0xFF4A5560)

// Семантика
val CbError = Color(0xFFFF5449)
val CbSuccess = Color(0xFF1DD18B)
val CbWarning = Color(0xFFFFB238)
