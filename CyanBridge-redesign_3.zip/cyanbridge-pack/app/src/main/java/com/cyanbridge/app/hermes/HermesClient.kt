package com.cyanbridge.app.hermes

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Клиент к УЖЕ РАЗВЁРНУТОМУ у пользователя Hermes (Nous Research hermes-agent).
 *
 * API подтверждён по документации: OpenAI-совместимый сервер.
 *   GET  {base}/health                 -> {"status":"ok"}
 *   POST {base}/v1/chat/completions     (Bearer auth, OpenAI-формат)
 *
 * Базовый URL обычно вида http://host:8642  (путь /v1 добавляется здесь).
 * Модель в запросе косметическая — реальная задаётся в config.yaml сервера,
 * но поле передаём, т.к. оно требуется форматом.
 */
class HermesClient(
    private val baseUrl: String,
    private val apiKey: String,
    private val model: String = "hermes-agent",
    timeoutSeconds: Long = 120,
) {
    private val http = OkHttpClient.Builder()
        .connectTimeout(10, TimeUnit.SECONDS)
        .readTimeout(timeoutSeconds, TimeUnit.SECONDS)
        .build()

    private val jsonMedia = "application/json; charset=utf-8".toMediaType()
    private val base = baseUrl.trimEnd('/')

    /** Проверка доступности сервера. */
    suspend fun health(): Result<Boolean> = withContext(Dispatchers.IO) {
        runCatching {
            val req = Request.Builder().url("$base/health").get().apply {
                if (apiKey.isNotBlank()) header("Authorization", "Bearer $apiKey")
            }.build()
            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return@runCatching false
                val body = resp.body?.string().orEmpty()
                body.contains("\"status\"") && body.contains("ok")
            }
        }
    }

    /**
     * Отправить текст пользователя и получить ответ ассистента.
     * @param systemPrompt опциональная системная инструкция (добавляется
     *   поверх ядра Hermes — так работает его API).
     */
    suspend fun chat(
        userText: String,
        systemPrompt: String? = null,
        history: List<ChatTurn> = emptyList(),
    ): Result<String> = withContext(Dispatchers.IO) {
        runCatching {
            val messages = JSONArray()
            systemPrompt?.let {
                messages.put(JSONObject().put("role", "system").put("content", it))
            }
            history.forEach { turn ->
                messages.put(JSONObject().put("role", turn.role).put("content", turn.content))
            }
            messages.put(JSONObject().put("role", "user").put("content", userText))

            val payload = JSONObject()
                .put("model", model)
                .put("messages", messages)
                .put("stream", false)

            val req = Request.Builder()
                .url("$base/v1/chat/completions")
                .post(payload.toString().toRequestBody(jsonMedia))
                .apply { if (apiKey.isNotBlank()) header("Authorization", "Bearer $apiKey") }
                .build()

            http.newCall(req).execute().use { resp ->
                val raw = resp.body?.string().orEmpty()
                if (!resp.isSuccessful) {
                    throw HermesException("HTTP ${resp.code}: ${raw.take(200)}")
                }
                parseChatContent(raw)
            }
        }
    }

    private fun parseChatContent(raw: String): String {
        val obj = JSONObject(raw)
        val choices = obj.optJSONArray("choices")
            ?: throw HermesException("Ответ без choices")
        if (choices.length() == 0) throw HermesException("Пустой choices")
        val message = choices.getJSONObject(0).optJSONObject("message")
            ?: throw HermesException("Ответ без message")
        return message.optString("content").trim()
    }
}

/** Одно сообщение истории для контекста. */
data class ChatTurn(val role: String, val content: String)

class HermesException(message: String) : Exception(message)
