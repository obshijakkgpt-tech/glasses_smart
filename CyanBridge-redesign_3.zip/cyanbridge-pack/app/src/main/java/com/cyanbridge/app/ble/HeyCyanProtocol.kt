package com.cyanbridge.app.ble

import com.cyanbridge.app.domain.DeviceMode
import java.util.UUID

/**
 * Таблица протокола HeyCyan — ЕДИНСТВЕННОЕ место, где живут константы
 * и формат пакетов. Скелет BLE (GattClient) использует только это.
 *
 * Что здесь ДОСТОВЕРНО (из публичной документации SDK / release notes):
 *   - Primary/Secondary Service UUID.
 *   - Набор и порядок режимов устройства (QCOperatorDeviceMode).
 *
 * Что требует ВРЕЗКИ из исходников ветки `manufacturer-original`
 * (помечено TODO(protocol)): UUID характеристик command/notify/data,
 * точные байты команд, формат чек-суммы и кадра нотификации.
 *
 * Менять надо ТОЛЬКО этот файл — остальной код подхватит изменения.
 */
object HeyCyanProtocol {

    // --- Сервисы (достоверно известны) ---
    val PRIMARY_SERVICE: UUID = UUID.fromString("7905FFF0-B5CE-4E99-A40F-4B1E122D00D0")
    val SECONDARY_SERVICE: UUID = UUID.fromString("6e40fff0-b5a3-f393-e0a9-e50e24dcca9e")

    // --- Характеристики ---
    // TODO(protocol): подставить реальные UUID из исходников.
    // Известно лишь НАЗНАЧЕНИЕ (command / notify / data-transfer).
    // Частый паттерн у таких устройств: FFF1=write, FFF2=notify, FFF6=data —
    // НО это предположение. Не использовать в проде без подтверждения.
    val COMMAND_CHARACTERISTIC: UUID = UUID.fromString("00007905-0000-1000-8000-00805f9b34fb")
    val NOTIFY_CHARACTERISTIC: UUID = UUID.fromString("00007906-0000-1000-8000-00805f9b34fb")
    val DATA_CHARACTERISTIC: UUID = UUID.fromString("00007907-0000-1000-8000-00805f9b34fb")

    /** Standard CCCD — стандартен, достоверно. */
    val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    /**
     * Команда смены режима устройства.
     * TODO(protocol): заменить тело на реальную сериализацию пакета
     * (header + payload(mode) + checksum) из исходников QCSDKCmdCreator.
     * Сейчас бросает NotImplemented, чтобы скелет НЕ делал вид, что работает.
     */
    fun encodeSetMode(mode: DeviceMode): ByteArray =
        throw ProtocolNotWired("encodeSetMode($mode)")

    /** TODO(protocol): запрос батареи. */
    fun encodeGetBattery(): ByteArray =
        throw ProtocolNotWired("encodeGetBattery")

    /** TODO(protocol): запрос счётчиков медиа. */
    fun encodeGetMediaCounts(): ByteArray =
        throw ProtocolNotWired("encodeGetMediaCounts")

    /** TODO(protocol): запрос версий. */
    fun encodeGetVersionInfo(): ByteArray =
        throw ProtocolNotWired("encodeGetVersionInfo")

    /**
     * Разбор кадра нотификации в типизированное событие.
     * TODO(protocol): реализовать по формату из исходников.
     */
    fun decodeNotification(bytes: ByteArray): DeviceEvent =
        DeviceEvent.Unknown(bytes)

    /** Признак, что таблица протокола ещё не заполнена реальными байтами. */
    val isWired: Boolean = false
}

/** Бросается, когда вызвана команда, чьи байты ещё не врезаны из исходников. */
class ProtocolNotWired(what: String) :
    UnsupportedOperationException(
        "Протокол HeyCyan не подключён: $what. " +
            "Врежьте байты из ветки manufacturer-original в HeyCyanProtocol.",
    )

/** Типизированные события, приходящие в нотификациях от очков. */
sealed interface DeviceEvent {
    data class Battery(val percent: Int, val charging: Boolean) : DeviceEvent
    data class Media(val photos: Int, val videos: Int, val audios: Int) : DeviceEvent
    data class Version(
        val hardware: String?,
        val firmware: String?,
        val hardwareWifi: String?,
        val firmwareWifi: String?,
    ) : DeviceEvent
    data class ModeChanged(val mode: DeviceMode?) : DeviceEvent
    data class Unknown(val raw: ByteArray) : DeviceEvent {
        override fun equals(other: Any?): Boolean =
            this === other || (other is Unknown && raw.contentEquals(other.raw))
        override fun hashCode(): Int = raw.contentHashCode()
    }
}
