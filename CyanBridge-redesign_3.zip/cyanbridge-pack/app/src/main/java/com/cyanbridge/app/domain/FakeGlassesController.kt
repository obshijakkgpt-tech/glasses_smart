package com.cyanbridge.app.domain

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.channelFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Симуляция контроллера для разработки UI и Compose @Preview БЕЗ физических очков.
 *
 * Это инструмент разработки, а не продакшн-заглушка: он осознанно имитирует
 * реальные тайминги и переходы состояний, чтобы экраны можно было проверять
 * визуально и в превью. В релизной сборке используется реальная реализация.
 */
class FakeGlassesController(
    private val scope: CoroutineScope = CoroutineScope(SupervisorJob() + Dispatchers.Default),
) : GlassesController {

    private val _state = MutableStateFlow(DeviceState())
    override val state: StateFlow<DeviceState> = _state.asStateFlow()

    override val discoveries: Flow<List<DiscoveredDevice>> = channelFlow {
        val found = mutableListOf<DiscoveredDevice>()
        val candidates = listOf(
            DiscoveredDevice("AA:BB:CC:11:22:33", "HeyCyan Glasses", -54),
            DiscoveredDevice("AA:BB:CC:44:55:66", "HeyCyan-A7F2", -78),
            DiscoveredDevice("AA:BB:CC:77:88:99", "Cyan-DEV", -85),
        )
        for (d in candidates) {
            if (!isActive) break
            delay(700)
            found.add(d)
            send(found.toList())
        }
    }

    override fun startScan() {
        _state.value = _state.value.copy(connection = ConnectionState.SCANNING)
    }

    override fun stopScan() {
        if (_state.value.connection == ConnectionState.SCANNING) {
            _state.value = _state.value.copy(connection = ConnectionState.DISCONNECTED)
        }
    }

    override suspend fun connect(address: String): Result<Unit> {
        _state.value = _state.value.copy(connection = ConnectionState.CONNECTING)
        delay(900)
        _state.value = _state.value.copy(
            connection = ConnectionState.CONNECTED,
            device = DiscoveredDevice(address, "HeyCyan Glasses", -54),
            battery = BatteryStatus(percent = 73, charging = false),
            media = MediaCounts(photos = 42, videos = 8, audios = 17),
            version = VersionInfo(firmware = "1.0.7", hardware = "W610"),
        )
        startBatteryDrift()
        return Result.success(Unit)
    }

    override suspend fun disconnect() {
        _state.value = _state.value.copy(connection = ConnectionState.DISCONNECTING)
        delay(300)
        _state.value = DeviceState()
    }

    override suspend fun takePhoto(): Result<Unit> {
        delay(400)
        _state.value = _state.value.copy(
            media = _state.value.media.copy(photos = _state.value.media.photos + 1),
        )
        return Result.success(Unit)
    }

    override suspend fun startVideo(): Result<Unit> {
        _state.value = _state.value.copy(activeMode = DeviceMode.VIDEO)
        return Result.success(Unit)
    }

    override suspend fun stopVideo(): Result<Unit> {
        _state.value = _state.value.copy(
            activeMode = null,
            media = _state.value.media.copy(videos = _state.value.media.videos + 1),
        )
        return Result.success(Unit)
    }

    override suspend fun startAudio(): Result<Unit> {
        _state.value = _state.value.copy(activeMode = DeviceMode.AUDIO)
        return Result.success(Unit)
    }

    override suspend fun stopAudio(): Result<Unit> {
        _state.value = _state.value.copy(
            activeMode = null,
            media = _state.value.media.copy(audios = _state.value.media.audios + 1),
        )
        return Result.success(Unit)
    }

    override suspend fun triggerAiPhoto(): Result<Unit> {
        _state.value = _state.value.copy(activeMode = DeviceMode.AI_PHOTO)
        delay(1500)
        _state.value = _state.value.copy(
            activeMode = null,
            media = _state.value.media.copy(photos = _state.value.media.photos + 1),
        )
        return Result.success(Unit)
    }

    override suspend fun refreshBattery(): Result<BatteryStatus> =
        Result.success(_state.value.battery)

    override suspend fun refreshMediaCounts(): Result<MediaCounts> =
        Result.success(_state.value.media)

    override suspend fun refreshVersionInfo(): Result<VersionInfo> =
        Result.success(_state.value.version)

    override suspend fun enterTransferMode(): Result<String> {
        _state.value = _state.value.copy(activeMode = DeviceMode.TRANSFER)
        delay(600)
        return Result.success("http://192.168.43.1")
    }

    override fun release() {
        // нет ресурсов для освобождения в симуляции
    }

    private fun startBatteryDrift() {
        scope.launch {
            while (isActive && _state.value.connection == ConnectionState.CONNECTED) {
                delay(15_000)
                val cur = _state.value.battery.percent
                if (cur > 1) {
                    _state.value = _state.value.copy(
                        battery = _state.value.battery.copy(percent = cur - 1),
                    )
                }
            }
        }
    }
}
