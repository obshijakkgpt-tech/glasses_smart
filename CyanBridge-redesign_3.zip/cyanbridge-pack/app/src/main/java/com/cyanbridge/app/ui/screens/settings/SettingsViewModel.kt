package com.cyanbridge.app.ui.screens.settings

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.cyanbridge.app.data.settings.AppSettings
import com.cyanbridge.app.data.settings.DeviceModeSetting
import com.cyanbridge.app.data.settings.SettingsRepository
import com.cyanbridge.app.hermes.HermesClient
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class TestResult { NONE, TESTING, OK, FAIL }

class SettingsViewModel(app: Application) : AndroidViewModel(app) {

    private val repo = SettingsRepository(app)

    val settings: StateFlow<AppSettings> =
        repo.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), AppSettings())

    private val _testResult = MutableStateFlow(TestResult.NONE)
    val testResult: StateFlow<TestResult> = _testResult.asStateFlow()

    fun setHermesUrl(v: String) = update { it.copy(hermesUrl = v) }
    fun setHermesKey(v: String) = update { it.copy(hermesApiKey = v) }
    fun setModel(v: String) = update { it.copy(openRouterModel = v) }
    fun setTtsLang(v: String) = update { it.copy(ttsVoiceLanguage = v) }
    fun setSttLang(v: String) = update { it.copy(sttLanguage = v) }
    fun setMode(v: DeviceModeSetting) = update { it.copy(deviceMode = v) }

    private fun update(transform: (AppSettings) -> AppSettings) {
        viewModelScope.launch { repo.update(transform) }
    }

    fun testConnection() {
        viewModelScope.launch {
            _testResult.value = TestResult.TESTING
            val s = repo.settings.first()
            if (s.hermesUrl.isBlank()) {
                _testResult.value = TestResult.FAIL
                return@launch
            }
            val client = HermesClient(s.hermesUrl, s.hermesApiKey, s.openRouterModel)
            val ok = client.health().getOrDefault(false)
            _testResult.value = if (ok) TestResult.OK else TestResult.FAIL
        }
    }
}
