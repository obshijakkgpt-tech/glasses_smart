package com.cyanbridge.app.domain

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.StateFlow

/**
 * Доменный контракт управления очками HeyCyan.
 *
 * UI и ViewModel зависят ТОЛЬКО от этого интерфейса. Конкретная реализация
 * протокола подключается отдельно:
 *   - QcsdkGlassesController     — обёртка над оригинальным QCSDK (.aar)
 *   - NativeBleGlassesController — собственный GATT-клиент на Android BLE API
 *   - FakeGlassesController      — для @Preview / разработки UI без железа
 *
 * Такой подход даёт "минимум изменений": смена реализации протокола не
 * затрагивает экраны.
 */
interface GlassesController {

    /** Текущее агрегированное состояние устройства (горячий поток). */
    val state: StateFlow<DeviceState>

    /** Поток найденных устройств во время сканирования. */
    val discoveries: Flow<List<DiscoveredDevice>>

    // --- Поиск и соединение ---
    fun startScan()
    fun stopScan()
    suspend fun connect(address: String): Result<Unit>
    suspend fun disconnect()

    // --- Команды управления (зеркалят QCSDKCmdCreator) ---
    /** Снять фото (setDeviceMode: Photo). */
    suspend fun takePhoto(): Result<Unit>

    /** Старт/стоп видеозаписи (Video / VideoStop). */
    suspend fun startVideo(): Result<Unit>
    suspend fun stopVideo(): Result<Unit>

    /** Старт/стоп аудиозаписи (Audio / AudioStop). */
    suspend fun startAudio(): Result<Unit>
    suspend fun stopAudio(): Result<Unit>

    /** Запустить AI-генерацию изображения (AIPhoto). */
    suspend fun triggerAiPhoto(): Result<Unit>

    // --- Запросы состояния ---
    suspend fun refreshBattery(): Result<BatteryStatus>
    suspend fun refreshMediaCounts(): Result<MediaCounts>
    suspend fun refreshVersionInfo(): Result<VersionInfo>

    /**
     * Перевести очки в режим Transfer (поднять WiFi-точку) для последующей
     * выгрузки медиа по HTTP. Возвращает IP-адрес/базовый URL, если известен.
     */
    suspend fun enterTransferMode(): Result<String>

    /** Закрыть ресурсы (GATT, потоки). */
    fun release()
}
