package com.cyanbridge.app.net

/** Тип медиафайла на устройстве. */
enum class MediaType { PHOTO, VIDEO, AUDIO, UNKNOWN }

/** Один элемент манифеста media.config. */
data class MediaItem(
    val name: String,
    val type: MediaType,
    val sizeBytes: Long? = null,
) {
    val downloadPath: String get() = "/files/$name"
}

/**
 * Разбор манифеста /files/media.config.
 *
 * Точный формат манифеста апстрима достоверно не задокументирован публично,
 * поэтому парсер устойчив к нескольким форматам: JSON-массив объектов,
 * JSON со списком под ключом, либо построчный список имён файлов.
 * Тип определяется по расширению (jpg/mp4/opus — из release notes).
 */
object MediaManifestParser {

    fun parse(raw: String): List<MediaItem> {
        val trimmed = raw.trim()
        return when {
            trimmed.startsWith("[") || trimmed.startsWith("{") -> parseJsonLenient(trimmed)
            else -> parsePlainList(trimmed)
        }
    }

    private fun parsePlainList(raw: String): List<MediaItem> =
        raw.lineSequence()
            .map { it.trim() }
            .filter { it.isNotEmpty() && !it.startsWith("#") }
            .map { MediaItem(it, typeOf(it)) }
            .toList()

    /**
     * Лёгкий разбор без сторонних библиотек: вытаскиваем имена файлов с
     * известными расширениями из любого JSON-подобного текста. Это надёжно,
     * пока не известен точный ключ-формат; при появлении точной схемы из
     * исходников апстрима — заменить на строгий парсинг.
     */
    private fun parseJsonLenient(raw: String): List<MediaItem> {
        val regex = Regex("\"?([\\w./-]+\\.(?:jpg|jpeg|png|mp4|mov|opus|wav))\"?", RegexOption.IGNORE_CASE)
        return regex.findAll(raw)
            .map { it.groupValues[1].substringAfterLast('/') }
            .distinct()
            .map { MediaItem(it, typeOf(it)) }
            .toList()
    }

    private fun typeOf(name: String): MediaType {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "jpg", "jpeg", "png" -> MediaType.PHOTO
            "mp4", "mov" -> MediaType.VIDEO
            "opus", "wav" -> MediaType.AUDIO
            else -> MediaType.UNKNOWN
        }
    }
}
